/** 
 * 
 * @author Joan Alba Maldonado
 */ 

package logica.multijugador;


public class Servidor
{
    public Servidor()
    {
    }
}
