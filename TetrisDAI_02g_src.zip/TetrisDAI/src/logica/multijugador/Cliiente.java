/** 
 * 
 * @author Joan Alba Maldonado
 */ 

//Falta: en totes les classes, impedir ficar valors no possibles en els sets (valors negatius, etc).

package logica.multijugador;


public class Cliiente
{
    public Cliiente()
    {
    }
}
